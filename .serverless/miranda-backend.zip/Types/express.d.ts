declare namespace Express {
   export interface Request {
      userID?: string
   }
}